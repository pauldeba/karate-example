# karate-example

For training: to show TDM, Selenium, and Docker functionality with Karate.


## Setup VSCode

Setup VSCode like this, for debugging.

![VSCode Setup](https://github.standard.com/QA/karate-example/blob/master/karateSetup.png)
