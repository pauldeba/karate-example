package com.standard.qa.listeners;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Profile({"local"})
public class WMBLocalConsumer {

    @JmsListener(destination = "${ibm.mq.consumerQueue}", containerFactory = "jmsListenerContainerFactory")
    public void receiveMessage(String msg) {
        log.info("received msg: {}", msg);
    }

}
