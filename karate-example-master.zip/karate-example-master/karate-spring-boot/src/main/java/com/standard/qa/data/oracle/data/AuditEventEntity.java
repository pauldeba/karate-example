package com.standard.qa.data.oracle.data;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name=AuditEventEntity.CREDENTIALS_TABLE, schema=AuditEventEntity.SCHEMA)
@Data
public class AuditEventEntity {

    public static final String CREDENTIALS_TABLE = "AUDIT_EVENT";
    public static final String SCHEMA = "SIC";

    @Id
    @Column(name = "AUDIT_EVENT_SEQ")
    private String eventSeq;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "AUDIT_EVENT_DTT")
    Date eventDate;

    @Column(name = "SOURCE_SUBCOMPONENT_ID")
    private String service;

    @Column(name = "AUDIT_EVENT_TXT")
    private String eventType;

    @Column(name = "MESSAGE")
    private String message;

}
