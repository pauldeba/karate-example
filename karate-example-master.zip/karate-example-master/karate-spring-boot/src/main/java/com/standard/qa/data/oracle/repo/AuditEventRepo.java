package com.standard.qa.data.oracle.repo;

import com.standard.qa.data.tdm.data.CredentialsEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditEventRepo extends JpaRepository<CredentialsEntity, String> {

    @Query(value = "SELECT eventSeq, eventDate, service, eventType, message FROM AuditEventEntity WHERE service = ?1 AND eventDate > current_timestamp - ( ?2 /(24*60))")
    List<String> findByService(@Param("service") String serviceName, @Param("maxMinutes") Integer maxMinutes, Pageable pageable);

}
