package com.standard.qa.controllers;

import com.standard.qa.data.tdm.repo.TDMRepo;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.exception.DataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLDataException;

@RestController
@Slf4j
public class TDMTestController {

    @Autowired
    TDMRepo TDMRepo;

    // EX: http://localhost:8080/credential/EBERSTMTCISQA
    @GetMapping("/credential/{key}")
    public String getCredential( @PathVariable String key) {
        return TDMRepo.findById(key)
                .orElseThrow(() -> new DataException("Missing data for credential.", new SQLDataException()))
                .getCredential();
    }

}
