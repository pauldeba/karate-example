package com.standard.qa.mq;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class WMQAuditUtils {

    private static final int INDENT_FACTOR = 4;

    private final JmsTemplate auditJmsTemplate;
    private final RetryTemplate retryTemplate;

    @Value("${ibm.mq.destination}")
    private String destination;

    public String sendMessage(String queue, String msg) {
        return retryTemplate.execute(retryContext -> {
            auditJmsTemplate.convertAndSend(queue, msg);
            log.info("produced message:\n{}", formatJson(msg));
            return msg;
        });
    }

    public String sendMessage(String msg) {
        return retryTemplate.execute(retryContext -> {
            auditJmsTemplate.convertAndSend(destination, msg);
            log.info("produced message:\n{}", formatJson(msg));
            return msg;
        });
    }

    public String readMessage(String queue) {
        return retryTemplate.execute(__ -> {
            String msg = (String) auditJmsTemplate.receiveAndConvert(queue);
            log.info("consumed message:\n{} ", formatJson(msg));
            return msg;
        });
    }

    public String readMessage() {
        return retryTemplate.execute(__ -> {
            String msg = (String) auditJmsTemplate.receiveAndConvert(destination);
            log.info("consumed message:\n{} ", formatJson(msg));
            return msg;
        });
    }

    public String formatJson(String msg) {
        try {
            JSONObject json = new JSONObject(msg);
            return json.toString(INDENT_FACTOR);
        } catch (JSONException e) {
            log.error("Error formatting JSON string.", e);
            return msg;
        }
    }

}
