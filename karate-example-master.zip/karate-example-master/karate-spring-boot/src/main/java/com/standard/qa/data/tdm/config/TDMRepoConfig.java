package com.standard.qa.data.tdm.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

/**
 * Because there are 2 datasources in this project, we cannot just use the default Spring JPA wiring
 *   and so here we manually and explicitly define the connection with custom bean names
 *   and custom property file locations.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "tdmEntityManagerFactory",
        transactionManagerRef = "tdmTransactionManager",
        basePackages = {"com.standard.qa.data.tdm"}
)
public class TDMRepoConfig {

    @Primary
    @Bean(name = "tdmDataSource")
    @ConfigurationProperties(prefix = "tdm.datasource")
    public DataSource claimDataSource() {
        String tdmPassword = System.getProperty("DB.password", "undefined");
        return DataSourceBuilder.create()
                .password(tdmPassword)
                .build();
    }

    @Primary
    @Bean(name = "tdmEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
                                                  @Qualifier("tdmDataSource") DataSource dataSource) {
        return builder.dataSource(dataSource)
                .packages("com.standard.qa")
                .persistenceUnit("tdm.datasource")
                .build();
    }

    @Primary
    @Bean(name = "tdmTransactionManager")
    public PlatformTransactionManager tdmTransactionManager(
            @Qualifier("tdmEntityManagerFactory") EntityManagerFactory tdmEntityManagerFactory) {
        return new JpaTransactionManager(tdmEntityManagerFactory);
    }

}
