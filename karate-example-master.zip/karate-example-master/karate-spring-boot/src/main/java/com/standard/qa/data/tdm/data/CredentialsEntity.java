package com.standard.qa.data.tdm.data;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name=CredentialsEntity.CREDENTIALS_TABLE)
@Data
public class CredentialsEntity {

    public static final String CREDENTIALS_TABLE = "CoreApps_Credentials";

    @Id
    private String identifier;

    private String credential;

}
