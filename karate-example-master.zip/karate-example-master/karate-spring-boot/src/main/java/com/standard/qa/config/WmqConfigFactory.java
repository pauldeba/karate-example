package com.standard.qa.config;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import com.standard.qa.data.tdm.repo.TDMRepo;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.exception.DataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.JmsException;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.backoff.FixedBackOff;

import javax.jms.JMSException;
import javax.net.ssl.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertPathBuilder;
import java.security.cert.PKIXBuilderParameters;
import java.security.cert.PKIXRevocationChecker;
import java.security.cert.X509CertSelector;
import java.sql.SQLDataException;
import java.util.EnumSet;

/**
 * Remote MQ connection factory with SSL connectivity.
 */
@Configuration
@EnableJms
@Setter
@Getter
@ToString
@Slf4j
@Profile({"int", "sys", "acc"})
public class WmqConfigFactory {

    private static final long RECEIVE_TIMEOUT = 30000L;
    private static final String KEYSTORE_PASS = "mq$client";
    private static final String JKS_FILE = "src/test/resources/mq_client.jks";

    static {
        System.setProperty("com.ibm.msg.client.commonservices.trace.outputName", "wmqjms.log");
        System.setProperty("com.ibm.msg.client.commonservices.trace.level", "5");
        System.setProperty("com.ibm.msg.client.commonservices.trace.status", "ON");
    }

    @Value("${spring.application.name}")
    private String applicationName;

    @Value("${ibm.mq.queueManager}")
    private String queueManager;

    @Value("${ibm.mq.channel}")
    private String channel;

    @Value("${ibm.mq.hostName}")
    private String hostName;

    @Value("${ibm.mq.port}")
    private int port;

    @Value("${ibm.mq.username}")
    private String username;

    @Value("${ibm.mq.timeout}")
    private long timeout;

    @Value("${ibm.mq.maxAttempts}")
    private int maxAttempts;

    @Value("${ibm.mq.destination}")
    private String destination;

    @Value("${ibm.mq.sslCipherSpec}")
    private String cipher;

    @Value("${ibm.mq.mqCspAuthenable}")
    private boolean mqCspAuthenable;

    @Value("${ibm.mq.useIbmCipherMappings}")
    private String useIbmCipherMappings;

    @Autowired
    private TDMRepo TDMRepo;

    public String getPassword() {
        return TDMRepo.findById(username)
                .orElseThrow(() -> new DataException("Missing data for password credential.", new SQLDataException()))
                .getCredential();
    }

    @Bean(name = "remoteMQConnectionFactory")
    public MQQueueConnectionFactory remoteMQConnectionFactory() {
        MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
        try {
            mqQueueConnectionFactory.setHostName(hostName);
            mqQueueConnectionFactory.setQueueManager(queueManager);
            mqQueueConnectionFactory.setPort(port);
            mqQueueConnectionFactory.setChannel(channel);
            mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
            mqQueueConnectionFactory.setAppName(applicationName);

            mqQueueConnectionFactory.setStringProperty(WMQConstants.USERID, username);
            mqQueueConnectionFactory.setStringProperty(WMQConstants.PASSWORD, getPassword());
            mqQueueConnectionFactory
                    .setBooleanProperty(WMQConstants.USER_AUTHENTICATION_MQCSP, mqCspAuthenable);
            mqQueueConnectionFactory.setStringProperty(WMQConstants.WMQ_SSL_CIPHER_SPEC, cipher);
            System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", useIbmCipherMappings);
            // the following 2 lines may not be necessary.  I am just explicitly loading the keystore for more control.
            //  SSLSocketFactory sslSocketFactory = sslContext().getSocketFactory();
            //  mqQueueConnectionFactory.setSSLSocketFactory(sslSocketFactory);
        } catch (JMSException je) {
            log.error("ERROR in MQ connection: " + je.getMessage());
        }
        return mqQueueConnectionFactory;
    }

    /**
     * For performance testing, be aware of the setReceiveTimeout variable below.
     * OR you can totally comment out this 'auto-consuming' bean if it gets in the way of your testing.
     * This listener is mapped to the 'consumerQueue' property.
     *
     * @param remoteMQConnectionFactory
     * @return
     */
//  @Bean(name = "jmsListenerContainerFactory")
//  public JmsListenerContainerFactory jmsListenerContainerFactory(MQQueueConnectionFactory remoteMQConnectionFactory) {
//    DefaultJmsListenerContainerFactory jmsListenerContainerFactory = new DefaultJmsListenerContainerFactory();
//    jmsListenerContainerFactory.setConnectionFactory(remoteMQConnectionFactory);
//    jmsListenerContainerFactory.setPubSubDomain(false);
//    jmsListenerContainerFactory.setReceiveTimeout(RECEIVE_TIMEOUT); //prevent infinite hanging
//    FixedBackOff fixedBackOff = new FixedBackOff();
//    fixedBackOff.setInterval(timeout);
//    fixedBackOff.setMaxAttempts(maxAttempts);
//    jmsListenerContainerFactory.setBackOff(fixedBackOff);
//    jmsListenerContainerFactory.setErrorHandler(error -> {
//      log.error("Error: " + error);
//    });
//    return jmsListenerContainerFactory;
//  }

    @Bean(name = "auditJmsTemplate")
    public JmsTemplate auditJmsTemplate(MQQueueConnectionFactory remoteMQConnectionFactory) {
        JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(remoteMQConnectionFactory);
        jmsTemplate.setDeliveryDelay(0);
        jmsTemplate.setReceiveTimeout(RECEIVE_TIMEOUT); //prevent infinite hanging
        return jmsTemplate;
    }

    @Bean(name = "retryTemplate")
    public RetryTemplate retryTemplate() {
        return RetryTemplate.builder()
                .infiniteRetry()
                .fixedBackoff(timeout)
                .retryOn(JmsException.class)
                .build();
    }

    /**
     * Timer for MicroMeter metric.  Requires the Spring-Boot server is still running.
     * http://localhost:8080/actuator/metrics/api.mq.put.time
     *
     * @param registry
     * @return
     */
    @Bean
    public Timer putMessageTimer(MeterRegistry registry) {
        return Timer
                .builder("api.mq.put.time")
                .description("Time taken to put a message on the queue.")
                .register(registry);
    }

    /**
     * Timer for MicroMeter metric.  Requires the Spring-Boot server is still running.
     * http://localhost:8080/actuator/metrics/api.mq.get.time
     *
     * @param registry
     * @return
     */
    @Bean
    public Timer getMessageTimer(MeterRegistry registry) {
        return Timer
                .builder("api.mq.get.time")
                .description("Time taken to get a message from the queue.")
                .register(registry);
    }

    /**
     * Loads a keystore explicitly if you want it.   Otherwise, spring boot will do this automagically.
     * @return SSLContext loaded keystore
     */
    public SSLContext sslContext() {
        File file = new File(JKS_FILE);
        String jkspath = file.getAbsolutePath();
        log.info("Keystore path: " + jkspath);
        try (InputStream cert = new FileInputStream(jkspath)) {
            final SSLContext sslContext = SSLContext.getInstance("TLS");
            final KeyStore caCertsKeyStore = KeyStore.getInstance("JKS");
            final KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            final TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            caCertsKeyStore.load(cert, KEYSTORE_PASS.toCharArray());
            CertPathBuilder cpb = CertPathBuilder.getInstance("PKIX");
            PKIXRevocationChecker rc = (PKIXRevocationChecker) cpb.getRevocationChecker();
            rc.setOptions(EnumSet.of(
                    PKIXRevocationChecker.Option.PREFER_CRLS,
                    PKIXRevocationChecker.Option.ONLY_END_ENTITY,
                    PKIXRevocationChecker.Option.SOFT_FAIL,
                    PKIXRevocationChecker.Option.NO_FALLBACK)
            );
            PKIXBuilderParameters pkixParams = new PKIXBuilderParameters(caCertsKeyStore, new X509CertSelector());
            pkixParams.addCertPathChecker(rc);
            kmf.init(caCertsKeyStore, KEYSTORE_PASS.toCharArray());
            tmf.init(new CertPathTrustManagerParameters(pkixParams));
            sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new SecureRandom());
            return sslContext;
        } catch (Exception e) {
            throw new RuntimeException("Exception creating SSLContext", e);
        }
    }


}