package com.standard.qa.config;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.JmsException;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.backoff.FixedBackOff;

import javax.jms.ConnectionFactory;

@Configuration
@EnableJms
@Data
@Slf4j
@Profile({"local"})
public class WmqLocalConfigFactory {

    static {
        System.setProperty("com.ibm.msg.client.commonservices.trace.outputName", "wmqjms-local.log");
        System.setProperty("com.ibm.msg.client.commonservices.trace.level", "5");
        System.setProperty("com.ibm.msg.client.commonservices.trace.status", "ON");
    }

    @Value("${ibm.mq.timeout}")
    private long timeout;

    @Bean
    public RetryTemplate retryTemplate() {
        return RetryTemplate.builder()
                .infiniteRetry()
                .fixedBackoff(timeout)
                .retryOn(JmsException.class)
                .build();
    }

    /**
     * Timer for MicroMeter metric.
     * http://localhost:8080/actuator/metrics/api.mq.put.time
     * @param registry
     * @return
     */
    @Bean
    public Timer putMessageTimer(MeterRegistry registry) {
        return Timer
                .builder("api.mq.put.time")
                .description("Time taken to put a message on the queue.")
                .register(registry);
    }

    /**
     * Timer for MicroMeter metric.
     * http://localhost:8080/actuator/metrics/api.mq.get.time
     * @param registry
     * @return
     */
    @Bean
    public Timer getMessageTimer(MeterRegistry registry) {
        return Timer
                .builder("api.mq.get.time")
                .description("Time taken to get a message from the queue.")
                .register(registry);
    }

    /**
     * Configures the JMS Listener Factory.
     * NOTE: Ignore the IntelliJ-IDEA intellisense 'connectionFactory' warning.  It is a side effect of our implementation, but works.
     * @param connectionFactory
     * @return a JmsListenerContainerFactory
     */
    @Bean
    public JmsListenerContainerFactory<?> jmsListenerContainerFactory(ConnectionFactory connectionFactory) {
        DefaultJmsListenerContainerFactory jmsListenerContainerFactory = new DefaultJmsListenerContainerFactory();

        jmsListenerContainerFactory.setConnectionFactory(connectionFactory);
        jmsListenerContainerFactory.setPubSubDomain(false);

        jmsListenerContainerFactory.setBackOff(new FixedBackOff(timeout, FixedBackOff.UNLIMITED_ATTEMPTS));
        jmsListenerContainerFactory.setErrorHandler(error -> log.error("Error while creating JMS Listener Container {}", error.toString()));

        return jmsListenerContainerFactory;
    }

}