package com.standard.qa.controllers;

import com.github.javafaker.Faker;
import com.standard.qa.mq.WMQAuditUtils;
import io.micrometer.core.instrument.Timer;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@Slf4j
public class WMQTestController {

    private final WMQAuditUtils utils;

    @Autowired
    private Timer putMessageTimer;

    @Autowired
    private Timer getMessageTimer;

    public WMQTestController(WMQAuditUtils utils) {
        this.utils = utils;
    }

    @GetMapping("/consume")
    @SneakyThrows
    public String consumeNext() {
        return getMessageTimer.recordCallable(() -> utils.readMessage());
    }

    @GetMapping("/produce")
    @SneakyThrows
    public String produceNext() {
        return putMessageTimer.recordCallable(() -> utils.sendMessage(getRandomJsonPayload().toString(4)));
    }

    @GetMapping("/consume/{queue}")
    @SneakyThrows
    public String consumeMessage(@PathVariable String queue) {
        return getMessageTimer.recordCallable(() -> utils.readMessage(queue));
    }

    @GetMapping("/produce/{queue}")
    @SneakyThrows
    public String produceMessage(@PathVariable String queue) {
        return putMessageTimer.recordCallable(() -> utils.sendMessage(queue, getRandomJsonPayload().toString(4)));
    }

    @GetMapping("/forward/{from}/{to}")
    @SneakyThrows
    public String forward(@PathVariable String from, @PathVariable String to) {
        return "forwarding: " + from + ": " + to + ":" + utils.sendMessage(to, consumeMessage(from));
    }

    private static JSONObject getRandomJsonPayload() {
        JSONObject queryJson = new JSONObject();
        try {
            queryJson.put("date", new Date());
            queryJson.put("message", "spring-boot-karate test harness: " + new Faker().lorem().paragraph(5));
        } catch (JSONException e) {
            log.error("Error creating JSON object payload.", e);
        }
        return queryJson;
    }

}
