package com.standard.qa.controllers;

import com.standard.qa.data.oracle.repo.AuditEventRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Slf4j
public class AUDITTestController {

    @Autowired
    AuditEventRepo auditEventRepo;

    /**
     * Filter event log by service name.
     * @param service name of service in the log
     * @param pageSize return results 1 page at a time with a pageSize
     * @param maxMinutes return only events within this number of minutes
     * @return
     */
    @GetMapping("/audit/{service}/{pageSize}/{maxMinutes}")
    public List<String> getAuditEventByServiceName(@PathVariable String service, @PathVariable Integer pageSize, @PathVariable Integer maxMinutes) {
        if (maxMinutes == 0) {
            maxMinutes = Integer.MAX_VALUE;
        }
        Pageable firstTen = PageRequest.of(0, pageSize, Sort.by("eventDate").descending());
        return auditEventRepo.findByService(service, maxMinutes, firstTen);
    }

}
