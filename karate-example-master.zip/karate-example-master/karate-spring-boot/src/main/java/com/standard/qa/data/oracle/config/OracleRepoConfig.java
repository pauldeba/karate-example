package com.standard.qa.data.oracle.config;

import com.standard.qa.data.tdm.repo.TDMRepo;
import org.hibernate.exception.DataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.sql.SQLDataException;
import java.util.HashMap;

/**
 * Because there are 2 datasources in this project, we cannot just use the default Spring JPA wiring
 *   and so here we manually and explicitly define the connection with custom bean names
 *   and custom property file locations.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "oraEntityManagerFactory",
        transactionManagerRef = "oraTransactionManager",
        basePackages = {"com.standard.qa.data.oracle"}
)
public class OracleRepoConfig {

    @Autowired
    TDMRepo TDMRepo;

    @Value("${oracle.datasource.username}")
    private String credentialKey;

    public String getCredential(String credentialKey) {
        return TDMRepo.findById(credentialKey)
                .orElseThrow(() -> new DataException("Missing data for credential.", new SQLDataException()))
                .getCredential();
    }

    @Bean(name = "oraDataSource")
    @ConfigurationProperties(prefix = "oracle.datasource")
    public DataSource oraDataSource() {
        String loadedPassword = getCredential(credentialKey);
        return DataSourceBuilder.create()
                .password(loadedPassword)
                .build();
    }

    @Bean(name = "oraEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
                                                  @Qualifier("oraDataSource") DataSource dataSource) {
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
        properties.put("hibernate.show-sql", "true");
        return builder.dataSource(dataSource)
                .packages("com.standard.qa")
                .persistenceUnit("oracle.datasource")
                .properties(properties)
                .build();
    }

    @Bean(name = "oraTransactionManager")
    public PlatformTransactionManager oraTransactionManager(
            @Qualifier("oraEntityManagerFactory") EntityManagerFactory oraEntityManagerFactory) {
        return new JpaTransactionManager(oraEntityManagerFactory);
    }

}
