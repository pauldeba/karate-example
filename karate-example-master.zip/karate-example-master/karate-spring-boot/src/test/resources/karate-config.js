
function() {
    var env = karate.properties['test.env']

    karate.configure('connectTimeout', 10 * 1000)
    karate.configure('readTimeout', 30 * 1000)

    // these 2 variables are auto-set in the WmbTestServiceRunTests Java class
    var port = karate.properties['server.port'];
    if (!port) {
        port = 8080;
    }
    var host = karate.properties['server.host'];
    if (!host) {
        host = 'localhost';
    }

    var config = {
        base_url: 'http://' + host + ':' + port,
        env: env,
        global: read("classpath:global.json")[env],
        jdbc: read("classpath:jdbc.json")[env]
    };

    //for (p in config) {
    //    karate.log ("##### config: " + p, ": " + config[p])
    //}
    return config;
}
