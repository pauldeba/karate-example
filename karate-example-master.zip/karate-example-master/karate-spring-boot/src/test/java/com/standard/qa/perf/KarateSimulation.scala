package com.standard.qa.perf

import com.intuit.karate.gatling.PreDef._
import com.standard.qa.WmbTestServiceApplication
import io.gatling.core.Predef._
import org.springframework.boot.SpringApplication
import org.springframework.context.ConfigurableApplicationContext

import scala.concurrent.duration._

class KarateSimulation extends Simulation {

  // Because Maven Failsafe will not start Spring-Boot before the Gatling test, we hard code it.
  val app: ConfigurableApplicationContext = SpringApplication.run(classOf[WmbTestServiceApplication])
  Runtime.getRuntime.addShutdownHook(new Thread() {
    override def run(): Unit = app.stop()
  })

  val DEMO = scenario("DEMO").exec(karateFeature("classpath:features/wmq.feature"))

  setUp (
    DEMO.inject(
      constantUsersPerSec(2) during(30 seconds)
    )
  )

}
