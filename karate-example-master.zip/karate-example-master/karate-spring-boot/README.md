# karate-spring-boot

THIS is a test harness; not a microservice!!

Karate Tests running against a Spring Boot JMS proxy.    Also implements Gatling test wrapper for performance testing.

Works with a local Dockerized IBM MQ 9.1.2.0.  Setup of that is described below.   ALSO, you can modify the configuraiton to talk to a real MQ server.

Video Explanation: https://web.microsoftstream.com/video/a89a17ef-9173-4f01-aae9-37c94c98f834?st=575

# Test Execution

## Run Spring Boot server standalone

    mvn spring-boot:run -Dspring-boot.run.jvmArguments="-Dspring.profiles.active=int -DDB.password=TdmNonpr@d1"
    
It runs on port 8080.
    
## Execute Karate Integration Test

Start the regular unit test, by itself without triggering Gatling performance test.

    mvn clean test -Dspring.profiles.active=local -DDB.password=TdmNonpr@d1 -Dtest.env=int -Dtest.type=reg 

## Execute Karate Performance Test

To execute the `gatling:test` phase:

    mvn verify -Dspring.profiles.active=local -DDB.password=TdmNonpr@d1 -Dtest.env=int -Dtest.type=reg 


## Troubleshooting

If the test reports that the service is already running, force kill it with `lsof -i TCP:8080`.


# Setup MQ Service

A bash script to start the default MQ.   Docker MQ is not persistent but it can be configured to be persistent.
This command might need a tweak of the --volume option in order to work on Windows.

```
#!/usr/bin/env bash
## version is 9.1.2.0 at time of this documentation
docker run \
  --name mqdemo \
  --env LICENSE=accept \
  --env MQ_QMGR_NAME=QM1 \
  --env MQ_ENABLE_METRICS=true \
  --env MQ_ENABLE_EMBEDDED_WEB_SERVER=true \
  --publish 1414:1414 \
  --publish 9009:9443 \
  --publish 9157:9157 \
  --detach \
  ibmcom/mq
```

## Other options you can include

- MQ_DEV - Set this to false to stop the default objects being created.
- MQ_ADMIN_PASSWORD - Changes the password of the admin user. Must be at least 8 characters long.
- MQ_APP_PASSWORD

## Related Info

* https://github.com/ibm-messaging/mq-container/blob/master/docs/usage.md
* https://github.com/ibm-messaging/mq-container/blob/master/docs/developer-config.md

## Administration

- Admin console so you can watch the queue:  https://localhost:9009/ibmmq/console
    -  User: admin
    -  Password: passw0rd

* Prometheus metrics:  http://localhost:9157/metrics
