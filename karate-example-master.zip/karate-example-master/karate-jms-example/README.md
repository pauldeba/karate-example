# karate-jms-example

An example project showing call to database to get managed test data.

## Execution Of Tests

Execute these tests with this Maven command, from this `services` sub-module folder:

    mvn clean test -Dtest.env=int -DDB.password=TdmNonpr@d1 -Dtest.type=reg

NOTE:  Don't try to run this in Powershell on Windows.  Use a cmd.exe prompt, or a Bash shell.

#### launch.json

This project comes with some `launch.json` examples for use in VSCode.

#### Running the Performance Tests

The performance tests are executed with the Maven Gatling plugin.   At the end of the test run, look for the Gatling
HTML report in the /target/gatling folder.

To run the performance tests, here is the command:

       mvn clean test-compile gatling:test -Dtest.env=int -DDB.password=TdmNonpr@d1 -Dtest.type=reg

WARNING: Do not increase the tests threads too high on this example because the services I hit probably cannot handle it.

## Debugging

To debug, use VSCode with the 'Karate Runner' plugin and the 'Java Extension Pack'.  
You will be able to put breakpoints on '.feature' files but not on '.js' files.

For Maven, VSCode will need to run the following command via `launch.json` :

    mvn test-compile -f \"${command:karateRunner.getDebugBuildFile}\" exec:java 
      -Dexec.mainClass=com.intuit.karate.cli.Main -Dexec.args=\"-d\" 
      -Dexec.classpathScope=\"test\" ${config:karateRunner.karateRunner.commandLineArgs} 
      -D\"test.env=int\" -D\"DB.password=TdmNonpr@d1\" -D\"test.type=reg\"

## Debugging In Java IDE

If you want to debug the Java code in a Java IDE, such as IntelliJ-IDEA, create a `Maven run configuration` like so.  You will not
be able to debug the Karate syntax in the `.feature` files this way.  For that, use `VSCode`.

    clean test -Dkarate.options=classpath:features/example_mssql.feature -Dtest.env=int -DDB.password=TdmNonpr@d1 -Dtest.type=reg


## Notes

Karate Documentation:
https://intuit.github.io/karate/

Karate JSON Transforms:
https://github.com/intuit/karate#json-transforms

Documentation at The Standard:
https://standard.atlassian.net/wiki/spaces/TESTSOL/pages/798785552/Karate+Test+Framework+API+Performance+Testing

