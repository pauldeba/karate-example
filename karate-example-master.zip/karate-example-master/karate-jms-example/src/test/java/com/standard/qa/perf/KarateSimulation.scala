package com.standard.qa.perf

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

  // https://gatling.io/docs/current/cheat-sheet
class KarateSimulation extends Simulation {

  val CONSUMER = scenario("CONSUMER").repeat(10) {
      exec(karateFeature("classpath:features/IA_consumer.feature"))
  }
  val PRODUCER = scenario("PRODUCER").repeat(10) {
      exec(karateFeature("classpath:features/IA_producer.feature"))
  }

  setUp (
    PRODUCER.inject(
      rampConcurrentUsers(4) to(0) during(100 seconds)
    ),
    CONSUMER.inject(
      rampConcurrentUsers(0) to(6) during(120 seconds)
    )
  )

}
