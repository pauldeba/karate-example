package com.standard.qa.jms;

import com.intuit.karate.PerfContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import java.util.Map;
import java.util.Objects;

public class KarateMessageConsumer extends JMSConnection {

    private static final Logger logger = LoggerFactory.getLogger(KarateMessageConsumer.class);

    private static final Long CONSUMER_MAX_WAIT = 20000L; // adjust depending on scenario

    private MessageConsumer consumer;

    public KarateMessageConsumer(final Map<String, Object> config) {
        super(config);
    }

    public void consumeMessage(PerfContext context) {
        long startTime = System.currentTimeMillis();
        resetSuccessStatus();
        try {
            consumer = getSession().createConsumer(getDestination());
            try {
                logger.info("Attempting to consume a message ... (timeout: " + CONSUMER_MAX_WAIT/1000 + " seconds)");
                consumer.receive(CONSUMER_MAX_WAIT);
                setSuccessStatus(true);
            } catch (Exception e) {
                setSuccessStatus(false);
                logger.error("Problem during dequeue of message.", e);
            } finally {
                logger.info("Cleanup consumer object, but retaining the connection...");
                try {
                    if (Objects.nonNull(consumer)) {
                        consumer.close();
                        consumer = null;
                    }
                } catch (JMSException je1) {
                    logger.error("Problem occurred closing the message Consumer:\n" + je1.getMessage());
                }
            }
        } catch (JMSException je0) {
            logger.error("Problem occurred creating a new message Consumer:\n" + je0.getMessage());
        }
        long endTime = System.currentTimeMillis();
        context.capturePerfEvent("consumer", startTime, endTime);
        logger.info("Finished consuming message: " + getSuccessStatus());
    }

}
