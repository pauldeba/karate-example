package com.standard.qa.test;

import com.intuit.karate.FileUtils;
import com.intuit.karate.JsonUtils;
import com.intuit.karate.http.HttpLogModifier;
import com.jayway.jsonpath.DocumentContext;

/**
 * This class is just an example.  
 * Be aware that masking fields in HTTP queries makes it hard for others to debug your work.
 */
public class LogMasker implements HttpLogModifier {
    
    public static final HttpLogModifier INSTANCE = new LogMasker();

    @Override
    public boolean enableForUri(String uri) {
        return uri.contains("/todos");
    }

    @Override
    public String uri(String uri) {
        return uri;
    }        

    @Override
    public String header(String header, String value) {
        // Hide the cf-request-id header in the logs
        if (header.toLowerCase().contains("cf-request-id")) {
            return "*****";
        }
        return value;
    }

    @Override
    public String request(String uri, String request) {
        return request;
    }

    @Override
    public String response(String uri, String response) {
        // Hide userId from response in the log
        DocumentContext dc = JsonUtils.toJsonDoc(response);
        if ( dc.read("$.userId") != null ) {
            dc.set("$.userId", "*****");
        }
        return FileUtils.toPrettyString(dc.jsonString());
    }

}
