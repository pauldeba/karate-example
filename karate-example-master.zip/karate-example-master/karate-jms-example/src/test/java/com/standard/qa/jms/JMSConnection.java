package com.standard.qa.jms;

import com.google.common.collect.ImmutableMap;
import com.google.common.util.concurrent.Uninterruptibles;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.*;
import java.security.cert.*;
import java.util.EnumSet;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public abstract class JMSConnection {

    protected static final Logger logger = LoggerFactory.getLogger(JMSConnection.class);

    protected static final String KEYSTORE_PASS = "mq$client";
    protected static final String CLIENT_NAME = "jms-connection";
    protected static final String JKS_LOCATION = "src/test/resources/mq_client.jks";

    // volatile: This will tell the compiler to always read from, and write to, main memory, and not the CPU cache.
    private volatile static Connection connection;
    private volatile static Session session;
    private volatile static Destination destination;

    protected boolean SUCCESS_STATUS = false;
    protected Map<String, Object> CONFIG;

    protected JMSConnection(Map<String, Object> config) {
        CONFIG = ImmutableMap.copyOf(config);
        try {
            connection = getConnection();
            session = getSession();
            destination = getDestination();
            connection.start();
        } catch (Exception any) {
            throw new RuntimeException("Error initializing the SSL connection to MQ.", any);
        }
        logger.info("Initialized " + this.getClass().getSimpleName() + " connection successfully.");
    }

    protected Session getSession() throws JMSException {
        if (Objects.isNull(session) && !Objects.isNull(connection)) {
            synchronized(this) {
                session = getConnection().createSession(false, Session.AUTO_ACKNOWLEDGE);
            }
        }
        return Objects.requireNonNull(session);
    }

    protected Destination getDestination() throws JMSException {
        if (Objects.isNull(destination) && !Objects.isNull(session)) {
            synchronized(this) {
                 destination = getSession().createQueue(String.valueOf(CONFIG.get("name")));
            }
        }
        return Objects.requireNonNull(destination);
    }

    protected Connection getConnection() throws JMSException {
        if (Objects.isNull(connection)) {
            logger.info("Creating a new JMS connection...");
            synchronized(this) {
                connection = getMQConnectionFactory().createConnection();
                connection.setExceptionListener(new ExceptionListener() {
                    @Override
                    public void onException(JMSException exception) {
                        logger.error("Problem encountered with JMS Connection : " + exception.getMessage(), exception);
                        Uninterruptibles.sleepUninterruptibly(1, TimeUnit.SECONDS);
                        close();
                    }
                });
            }
        }
        return Objects.requireNonNull(connection);
    }

    private MQQueueConnectionFactory getMQConnectionFactory() {
        MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
        try {
            mqQueueConnectionFactory.setHostName(String.valueOf(CONFIG.get("host")));
            mqQueueConnectionFactory.setQueueManager(String.valueOf(CONFIG.get("manager")));
            mqQueueConnectionFactory.setPort((Integer) CONFIG.get("port"));
            mqQueueConnectionFactory.setChannel(String.valueOf(CONFIG.get("channel")));
            mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
            mqQueueConnectionFactory.setCCSID((Integer) CONFIG.get("ccsid")); // CCSID for OS type
            mqQueueConnectionFactory.setAppName(CLIENT_NAME);
            mqQueueConnectionFactory.setStringProperty(WMQConstants.WMQ_SSL_CIPHER_SPEC, "TLS_RSA_WITH_AES_128_GCM_SHA256");
            mqQueueConnectionFactory.setBooleanProperty(WMQConstants.USER_AUTHENTICATION_MQCSP, true);
            System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");

            mqQueueConnectionFactory.setStringProperty(WMQConstants.USERID, String.valueOf(CONFIG.get("user")));
            mqQueueConnectionFactory.setStringProperty(WMQConstants.PASSWORD, String.valueOf(CONFIG.get("secret")));

            final SSLSocketFactory sslSocketFactory = sslContext().getSocketFactory();
            mqQueueConnectionFactory.setSSLSocketFactory(sslSocketFactory);

        } catch (final JMSException e) {
            logger.error("Error in connection factory.", e);
        }
        logger.info("Initialized JMS connection factory.");
        return mqQueueConnectionFactory;
    }

    private SSLContext sslContext() {
        try (InputStream cert = new FileInputStream(JKS_LOCATION)) {

            final KeyStore caCertsKeyStore = KeyStore.getInstance("JKS");
            caCertsKeyStore.load(cert, KEYSTORE_PASS.toCharArray());

            final KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            final TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());

            final CertPathBuilder cpb = CertPathBuilder.getInstance("PKIX");
            final PKIXRevocationChecker rc = (PKIXRevocationChecker) cpb.getRevocationChecker();
            rc.setOptions(
                    EnumSet.of(PKIXRevocationChecker.Option.PREFER_CRLS, PKIXRevocationChecker.Option.ONLY_END_ENTITY,
                            PKIXRevocationChecker.Option.SOFT_FAIL, PKIXRevocationChecker.Option.NO_FALLBACK));

            final PKIXBuilderParameters pkixParams = new PKIXBuilderParameters(caCertsKeyStore, new X509CertSelector());
            pkixParams.addCertPathChecker(rc);

            kmf.init(caCertsKeyStore, KEYSTORE_PASS.toCharArray());
            tmf.init(new CertPathTrustManagerParameters(pkixParams));

            final SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new SecureRandom());
            logger.info("Returning SSL context from JMS connection.");
            return sslContext;

        } catch (final Exception e) {
            throw new RuntimeException("Exception creating SSLContext", e);
        }
    }

    public void close() {
        try {
            destination = null;
            if (Objects.nonNull(session)) {
                session.close();
                session = null;
            }
            if (Objects.nonNull(connection)) {
                logger.info("Closing connection object: " + connection.toString());
                connection.close();
                connection = null;
            } else {
                logger.info("JMS Connection was already closed.");
            }
            logger.info("Closed JMS " + this.getClass().getSimpleName() + " connection successfully.");
        } catch (final JMSException e) {
            logger.error("Problem occurred closing the connection.  JVM exit might clean it up:\n" + e.getMessage());
        }
    }

    public boolean getSuccessStatus() {
        return SUCCESS_STATUS;
    }

    public void setSuccessStatus(boolean flag) {
        SUCCESS_STATUS = flag;
    }

    public void resetSuccessStatus() {
        setSuccessStatus(false);
    }

}
