package com.standard.qa.jms;

import com.intuit.karate.PerfContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import java.util.Map;
import java.util.Objects;

public class KarateMessageProducer extends JMSConnection {

    private static final Logger logger = LoggerFactory.getLogger(KarateMessageProducer.class);

    private MessageProducer producer;

    public KarateMessageProducer(Map<String, Object> config) {
        super(config);
    }

    public void produceMessage(Map<String, Object> message, PerfContext context) {
        long startTime = System.currentTimeMillis();
        resetSuccessStatus();
        try {
            producer = getSession().createProducer(getDestination());
            try {
                logger.info("Sending message...");
                producer.send(getSession().createTextMessage(message.toString()));
                setSuccessStatus(true);
            } catch (Exception e) {
                logger.error("Problem during enqueue of message.", e);
            } finally {
                logger.info("Cleanup producer object, but retaining the connection...");
                try {
                    if (Objects.nonNull(producer)) {
                        producer.close();
                    }
                } catch (JMSException je1) {
                    logger.error("Problem occurred closing the message Producer:\n" + je1.getMessage());
                }
            }
        } catch (JMSException je0) {
            logger.error("Problem occurred creating a new message Producer:\n" + je0.getMessage());
        }
        long endTime = System.currentTimeMillis();
        context.capturePerfEvent("producer", startTime, endTime);
        logger.info("Finished producing message: " + getSuccessStatus());
    }

}
