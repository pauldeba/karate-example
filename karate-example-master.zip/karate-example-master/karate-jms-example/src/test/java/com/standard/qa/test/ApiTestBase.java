package com.standard.qa.test;

public abstract class ApiTestBase {

    public abstract void runAPITests();
    public abstract void generateReport(String karateOutputPath);

}
