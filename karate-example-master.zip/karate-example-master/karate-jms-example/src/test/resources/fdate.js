
function() { 
    var Faker = Java.type('com.github.javafaker.Faker');
    var Locale = Java.type('java.util.Locale');
    var TimeUnit = Java.type('java.util.concurrent.TimeUnit');
    var SimpleDateFormat = Java.type('java.text.SimpleDateFormat');
    var faker = new Faker(new Locale("en-US"));
    var futureDate = faker.date().future(30, TimeUnit.MINUTES);
    var format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z");
    return format.format(futureDate);
}

