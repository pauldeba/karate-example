
function() {
    var env = karate.properties['test.env']

    var config = {
        env: env,
        jdbc: read("classpath:jdbc.json")[env],
        global: read("classpath:global.json")[env]
    };

    // so that each test shows the configuration in the background step
    for (p in config) {
        karate.log ("##### config: " + p, ": " + config[p])
    }

    return config;
}
