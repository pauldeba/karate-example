package com.standard.qa.perf

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class KarateSimulation extends Simulation {

  val DB = scenario("DB").exec(karateFeature("classpath:features/example_db.feature"))
  val REST = scenario("REST").exec(karateFeature("classpath:features/example_rest.feature"))
  val SOAP = scenario("SOAP").exec(karateFeature("classpath:features/example_soap.feature"))

  setUp(
    DB.inject(
      incrementUsersPerSec(4)
        .times(2)
        .eachLevelLasting(30 seconds)
        .separatedByRampsLasting(10 seconds)
        .startingFrom(4)
    ),
    REST.inject(
      incrementUsersPerSec(4)
        .times(2)
        .eachLevelLasting(30 seconds)
        .separatedByRampsLasting(10 seconds)
        .startingFrom(4)
    ),
    SOAP.inject(
      incrementUsersPerSec(4)
        .times(2)
        .eachLevelLasting(30 seconds)
        .separatedByRampsLasting(10 seconds)
        .startingFrom(4)
    )
  ).maxDuration(2 minutes)

}
